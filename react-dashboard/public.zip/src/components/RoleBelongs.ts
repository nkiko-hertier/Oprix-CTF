
export const RoleBelongs: { [key: string]: string } = {
    "ADMIN": '/dashboard',
    "SUPERADMIN": '/dashboard',
    "USER": '/platform',
}