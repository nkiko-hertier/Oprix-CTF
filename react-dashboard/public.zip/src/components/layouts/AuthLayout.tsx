'use client'
import { MobileMenu } from "../../territories/landing/competitions/MobileMenu";
import { SignedOut, SignInButton, SignedIn } from "@clerk/clerk-react";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { FaLinkedin, FaFacebook } from "react-icons/fa";
import { GrTwitter } from "react-icons/gr";
import { TfiYoutube } from "react-icons/tfi";
import { Outlet } from "react-router-dom";

function AuthLayout() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [activeSection, setActiveSection] = useState("home")

  const toggleMenu = () => setMenuOpen(!menuOpen)

  // Detect which section is in view (scroll spy)
  useEffect(() => {
    const sections = document.querySelectorAll("section[id]")
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id)
          }
        })
      },
      { threshold: 0.4 }
    )
    sections.forEach(section => observer.observe(section))
    return () => sections.forEach(section => observer.unobserve(section))
  }, [])

  const scrollToSection = (id: string) => {
    const section = document.getElementById(id)
    if (section) {
      section.scrollIntoView({ behavior: "smooth" })
      setMenuOpen(false)
    }
  }
  return (
    <>
      <div className='bg-[#100E19] h-screen relative overflow-y-auto text-white'>
        <div className='md:p-10 p-5 stickys top-0 z-30'>
          <nav className='min-h-[70px] backdrop-blur-sm bg-slate-600/10 borders rounded-full border-[#4e486a] px-5 flex justify-between items-center'>
            <div className="logo flex px-2 gap-2 items-center">
              <ArrowLeft size={20} />
              <Link to={'/'}>Back Home</Link>
            </div>
            
            <div className='hidden md:block'>
              <SignedOut>
                <SignInButton>
                  <button className='bg-[#573BA8] p-3 px-7 rounded-full text-sm'>Get Started</button>
                </SignInButton>
              </SignedOut>
              <SignedIn>
                <Link to={'/platform'} className='bg-[#573BA8] flex gap-2 p-3 px-7 items-center rounded-full text-sm'>Dashboard <ArrowRight size={15} /> </Link>
              </SignedIn>
            </div>
            <div className=' md:hidden'>
              <MobileMenu scrollToSection={scrollToSection} activeSection={activeSection} />
            </div>
          </nav>
        </div>
        <div className="mx-auto min-h-[500px]">
          <Outlet />
        </div>
        {/* <BgSvg className="fixed opacity-80 right-0 -z-10 -top-2" />
        <BgSvg className="fixed opacity-80 left-0 scale-x-[-1] -z-10 -top-2" /> */}
        <footer className='bg-slate-600/10 min-h-[200px] mt-10 p-5'>
          <div className='grid md:grid-cols-2 md:w-[90%] mx-auto'>
            <div>
              <div className="logo flex gap-2 items-center">
                <img
                  src="/img/logo_icon.png"
                  alt="logo"
                  width={30}
                  height={30}
                  className="block max-md:hidden left-[-35px]"
                />
                <p>Oprix CTF</p>
              </div>
              <p className='md:w-[90%] mt-5 text-zinc-400'>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Architecto, eos. Magnam totam, ipsam repellat eum earum iusto nemo laudantium amet vero natus voluptatem odio alias veritatis distinctio illum ea dignissimos.</p>
              {/* Social Links */}
              <div className='flex gap-5 mt-5'>
                <Link to={'#'} className='bg-slate-800 p-3 rounded-full'>
                  <FaLinkedin />
                </Link>
                <Link to={'#'} className='bg-slate-800 p-3 rounded-full'>
                  <FaFacebook />
                </Link>
                <Link to={'#'} className='bg-slate-800 p-3 rounded-full'>
                  <GrTwitter />
                </Link>
                <Link to={'#'} className='bg-slate-800 p-3 rounded-full'>
                  <TfiYoutube />
                </Link>
              </div>
            </div>
            <div className="links">
              <ul className='flex gap-5 items-start mt-10 md:justify-end h-full'>
                <li><a href="#">Home</a></li>
                <li><a href="#">How it works</a></li>
                <li><a href="#">FAQ</a></li>
                <li><a href="#">Contact us</a></li>
              </ul>
            </div>
          </div>
          <div className='mt-10 md:w-[90%] mx-auto'>
            <p>&copy; Copyright Oprix 2025. All Right reserved.</p>
          </div>
        </footer>
      </div>
    </>
  );
}

export default AuthLayout;
